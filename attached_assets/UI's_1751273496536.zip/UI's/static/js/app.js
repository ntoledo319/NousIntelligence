/**
 * @file app.js
 * @description Client-side logic for the Flask Chat Application.
 * Handles UI interactions, theme management, responsive layout, and WebSocket communication.
 * @ai_prompt Use this file as a reference for implementing frontend chat functionality.
 * To add a new UI interaction, add a method to the ChatApp class and call it in the `init` method.
 */

// # AI-GENERATED [2024-05-21]
// # HUMAN-VALIDATED [2024-05-21]

class ChatApp {
    /**
     * Initializes the chat application by binding all event listeners and setting the initial state.
     */
    constructor() {
        this.socket = io();
        this.currentUserId = 'user123'; // Example ID; replace with actual user session data.

        // DOM element selectors
        this.selectors = {
            theme: {
                toggleBtn: '#theme-toggle',
                darkIcon: '#theme-toggle-dark-icon',
                lightIcon: '#theme-toggle-light-icon',
            },
            ui: {
                sidebar: '#sidebar',
                mainContent: 'main',
                backButton: '#back-to-conversations',
                conversationListItems: '#conversation-list li',
            },
            chat: {
                form: '#message-form',
                input: '#message-input',
                stream: '#message-stream',
                streamContainer: '#message-stream .space-y-4',
            }
        };

        // Cache DOM elements
        this.dom = {
            theme: {
                toggleBtn: document.querySelector(this.selectors.theme.toggleBtn),
                darkIcon: document.querySelector(this.selectors.theme.darkIcon),
                lightIcon: document.querySelector(this.selectors.theme.lightIcon),
            },
            ui: {
                sidebar: document.querySelector(this.selectors.ui.sidebar),
                mainContent: document.querySelector(this.selectors.ui.mainContent),
                backButton: document.querySelector(this.selectors.ui.backButton),
                conversationListItems: document.querySelectorAll(this.selectors.ui.conversationListItems),
            },
            chat: {
                form: document.querySelector(this.selectors.chat.form),
                input: document.querySelector(this.selectors.chat.input),
                stream: document.querySelector(this.selectors.chat.stream),
                streamContainer: document.querySelector(this.selectors.chat.streamContainer),
            }
        };
    }

    /**
     * Kicks off all the application's functionality.
     */
    init() {
        this.initTheme();
        this.initResponsiveUI();
        this.initWebSocketHandlers();
        console.log("ChatApp Initialized");
    }

    // --- THEME MANAGEMENT ---

    /**
     * Sets the initial color theme based on localStorage or system preference.
     * Binds the click event listener to the theme toggle button.
     */
    initTheme() {
        const isDarkMode = localStorage.getItem('color-theme') === 'dark' ||
            (!('color-theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches);
        this.updateTheme(isDarkMode);

        this.dom.theme.toggleBtn.addEventListener('click', () => {
            this.updateTheme(!document.documentElement.classList.contains('dark'));
        });
    }

    /**
     * Toggles the UI between light and dark mode.
     * @param {boolean} isDark - True to switch to dark mode, false for light mode.
     */
    updateTheme(isDark) {
        if (isDark) {
            document.documentElement.classList.add('dark');
            localStorage.setItem('color-theme', 'dark');
            this.dom.theme.lightIcon.classList.remove('hidden');
            this.dom.theme.darkIcon.classList.add('hidden');
        } else {
            document.documentElement.classList.remove('dark');
            localStorage.setItem('color-theme', 'light');
            this.dom.theme.lightIcon.classList.add('hidden');
            this.dom.theme.darkIcon.classList.remove('hidden');
        }
    }

    // --- RESPONSIVE UI ---

    /**
     * Binds event listeners to handle view changes on mobile devices.
     */
    initResponsiveUI() {
        this.dom.ui.conversationListItems.forEach(item => {
            item.addEventListener('click', () => {
                if (window.innerWidth < 768) this.showMainContent();
            });
        });

        this.dom.ui.backButton.addEventListener('click', () => {
            if (window.innerWidth < 768) this.showSidebar();
        });
    }

    showMainContent = () => {
        this.dom.ui.sidebar.classList.add('hidden');
        this.dom.ui.mainContent.classList.remove('hidden');
        this.dom.ui.mainContent.classList.add('flex');
    };

    showSidebar = () => {
        this.dom.ui.mainContent.classList.add('hidden');
        this.dom.ui.mainContent.classList.remove('flex');
        this.dom.ui.sidebar.classList.remove('hidden');
        this.dom.ui.sidebar.classList.add('flex');
    };


    // --- WEBSOCKETS & CHAT ---

    /**
     * Initializes WebSocket event listeners for chat functionality.
     */
    initWebSocketHandlers() {
        this.socket.on('connect', () => console.log('WebSocket connected.'));
        this.socket.on('new_message', (data) => this.appendMessage(data));

        this.dom.chat.form.addEventListener('submit', (e) => {
            e.preventDefault();
            const messageText = this.dom.chat.input.value.trim();
            if (messageText) {
                const messageData = { text: messageText, userId: this.currentUserId };
                this.socket.emit('send_message', messageData);
                this.appendMessage(messageData, true); // Optimistically append sent message
                this.dom.chat.input.value = '';
            }
        });
    }

    /**
     * Appends a new message to the chat stream.
     * @param {object} data - The message data ({ text, userId }).
     * @param {boolean} [isSent=false] - True if the message was sent by the current user.
     */
    appendMessage(data, isSent = false) {
        const { text } = data;
        const messageContainer = document.createElement('div');
        messageContainer.classList.add('flex', 'items-start', 'animate-fade-in-up');

        const messageBubble = document.createElement('div');
        messageBubble.classList.add('p-3', 'rounded-lg', 'max-w-md', 'shadow-sm');

        const paragraph = document.createElement('p');
        paragraph.classList.add('text-sm');
        paragraph.textContent = text;

        const timestamp = document.createElement('span');
        timestamp.classList.add('text-xs', 'mt-1', 'block', 'text-right');
        timestamp.textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        if (isSent) {
            messageContainer.classList.add('justify-end');
            messageBubble.classList.add('bg-brand', 'text-white');
            timestamp.classList.add('text-blue-100/70');
        } else {
            messageContainer.classList.add('justify-start');
            messageBubble.classList.add('bg-white', 'dark:bg-gray-700');
            timestamp.classList.add('text-gray-500', 'dark:text-gray-400');

            const avatar = document.createElement('img');
            avatar.classList.add('w-8', 'h-8', 'rounded-full', 'mr-3');
            avatar.src = 'https://i.pravatar.cc/150?u=other'; // Placeholder
            avatar.alt = "Avatar";
            messageContainer.appendChild(avatar);
        }

        messageBubble.appendChild(paragraph);
        messageBubble.appendChild(timestamp);
        messageContainer.appendChild(messageBubble);

        this.dom.chat.streamContainer.appendChild(messageContainer);
        this.dom.chat.stream.scrollTop = this.dom.chat.stream.scrollHeight;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const app = new ChatApp();
    app.init();
});
